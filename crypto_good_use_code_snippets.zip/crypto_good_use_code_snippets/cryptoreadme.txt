Good uses for crypto software programming

only the good stays here